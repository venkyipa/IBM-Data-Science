# Data-Visualization-with-Python-offered-by-IBM-on-Coursera

This repository contains all my hands-on lab on the IBM Data Analyst Professional Certificate offered by IBM on Coursera.

Visualization helps us understand and retain insights from the data we present to the stakeholders.
Throughout this course, I learned how to effectively visualize each piece of data for a better understanding using the appropriate graphical representation.
